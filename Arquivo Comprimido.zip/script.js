const createTaskButton = document.getElementById('criar-tarefa');
const deleteAllTasksButton = document.getElementById('apaga-tudo');
const deleteCompletedTasksButton = document.getElementById(
  'remover-finalizados'
);
const completeSelected = document.getElementById('completar-selecionado');
const taskToBeCreated = document.getElementById('texto-tarefa');
const taskList = document.getElementById('lista-tarefas');
let allTasks = [];

getFromLocalStorage();

function addToLocalStorage() {
  localStorage.setItem('todos', JSON.stringify(allTasks));
}

function getFromLocalStorage() {
  const reference = localStorage.getItem('todos');
  if (reference) {
    allTasks = JSON.parse(reference);
    renderTodos();
  }
}

function renderTodos() {
  allTasks.forEach((task) => {
    const element = document.createElement('li');
    element.innerText = task;
    taskList.appendChild(element);
  });
  console.log(taskList.children);
}

function createTask() {
  const task = document.createElement('li');
  task.innerText = taskToBeCreated.value;
  taskToBeCreated.value = '';
  taskList.appendChild(task);
  allTasks.push(task.innerText);
  addToLocalStorage(allTasks);
}

function changeBackgroundColor(event) {
  const selected = document.getElementsByClassName('selected');
  const targetedEvent = event.target;
  if (selected.length === 1) {
    selected[0].style.backgroundColor = '';
    selected[0].classList.remove('selected');
  }
  targetedEvent.style.backgroundColor = 'rgb(128, 128, 128)';
  targetedEvent.classList.add('selected');
}

function eventCompleted(event) {
  console.log(event);
  const completedEvent = event.target;
  console.log(completedEvent);
  if (!completedEvent.classList.contains('completed')) {
    completedEvent.style.textDecoration = 'line-through';
    completedEvent.classList.add('completed');
  } else {
    completedEvent.style.textDecoration = '';
    completedEvent.classList.remove('completed');
  }
  console.log(completedEvent);
}

function deleteAllTasks() {
  while (taskList.hasChildNodes()) {
    taskList.removeChild(taskList.firstChild);
    allTasks = [];
    addToLocalStorage();
  }
}

function deleteCompletedTasks() {
  let tasks = taskList.children;
  for (let index = 0; index < tasks.length; index += 1) {
    console.log(tasks[index]);
    if (tasks[index].classList.contains('completed')) {
      taskList.removeChild(taskList.children[index]);
      index -= 1;
    }
  }

  allTasks = [];

  tasks = taskList.children;

  for (let index = 0; index < tasks.length; index += 1) {
    console.log(tasks[index]);
    allTasks.push(tasks[index].innerHTML);
  }

  addToLocalStorage();
}

function completeCurrentSelected(e) {
  console.log(e);
  let tasks = taskList.children;
  for (let index = 0; index < tasks.length; index += 1) {
    console.log(tasks[index]);
    if (tasks[index].classList.contains('selected')) {
      if (tasks[index].classList.contains('completed')) {
        tasks[index].classList.remove('completed');
      } else {
        tasks[index].classList.add('completed');
      }
    }
  }
}

// Eventos dos elementos
createTaskButton.addEventListener('click', createTask);
deleteAllTasksButton.addEventListener('click', deleteAllTasks);
deleteCompletedTasksButton.addEventListener('click', deleteCompletedTasks);
completeSelected.addEventListener('click', completeCurrentSelected);
taskList.addEventListener('click', changeBackgroundColor);
